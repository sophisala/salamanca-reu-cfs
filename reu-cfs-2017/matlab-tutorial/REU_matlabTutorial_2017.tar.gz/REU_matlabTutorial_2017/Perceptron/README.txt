Scripts to be run are: 
- perceptron_demo.m to run Rosenblatt's perceptron algorithm 
- cross_enropy_demo.m to run logistic sigmoid with cross-entropy loss
- loss_demo.m to visualize different loss functions.
% 2016 Luis G Sanchez Giraldo and Odelia Schwartz

