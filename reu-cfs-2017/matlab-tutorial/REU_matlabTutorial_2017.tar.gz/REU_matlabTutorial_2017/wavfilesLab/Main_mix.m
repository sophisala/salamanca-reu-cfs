
%% 2017 Odelia Schwartz and Luis Gonzalo Sanchez Giraldo 
% UM REU
% Linear mixing of signals, sounds, and the cocktail party effect.
% Introduction to looking at the statistics.

% To get help type "help" (will give list of help topics) or "help topic"
% If you don't know the exact name of the topic or command you are looking for,
% type "lookfor keyword" 
% Use run and advance in Matlab interface to go step by step; 
% (or copy line by line into Matlab command window).

% This tutorial is written such that much of the code is in place, but
% *TODO* indicates to fill in the missing code.

clear all;
close all;

%% Linear mixing of Gaussian signals
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% (a) Gaussian distributions.
%%% *TODO*: Generate 40000 samples from two Gaussian distributions
%%% (using Matlab's randn) that are independent (call them, for
%%% instance, src1 and src2). Make a histogram of each of the signals 
%%% you have generated using the hist function. You can choose number of bins;
%%% see "help hist". You could use figure(1) and subplot(2,2,1) and subplot(2,2,2)
%%% for plotting each of the src1 and src2 distributions in separate subplots.

%% Make a scatter plot of src1 versus src2.
%%% You can do this in a new figure and subplot(2,2,1).

figure(2); clf;
subplot(2,2,1);
plot(src1, src2, 'o'); axis([-5 5 -5 5]);
axis('square');
title('src1 and src2');

%% *TODO* Create two vectors (mix1 and mix2) that are linear
%%% combinations of src1 and src2. (For instance, create a random
%%% matrix rmat of size 2 by 2, and set src1 equal to a weighted sum
%%% of src1 and src2 with the weights given by the first row of
%%% rmat and make src2 equal to a weighted sum with the weights
%%% given by the second row). Plot the 2D scatter plot of mix1
%%% versus mix2 in a new subplot (2,2,2). 

%% PCA
%%% Run PCA to uncorrelate the data and plot again
%%% the scatter plot. You can use the file mypca.m.
[newsig, evecs, evals, mat]=mypca([mix1; mix2]);

%% Plot the first and second principle components
%%%% We'll plot them at 3 times the standard deviation of the data.
u = evecs(:,2)
v = evecs(:,1);
sd = 3*sqrt(evals);
subplot(2,2,2);
hold on
h=plot([ 0 v(1)*sd(1)], [0 v(2)*sd(1)], 'r');       
set(h, 'linewidth', 3);
h=plot([ 0 -v(1)*sd(1)], [0 -v(2)*sd(1)], 'r');   
set(h, 'linewidth', 3);
h=plot([ 0 u(1)*sd(2)], [0 u(2)*sd(2)], 'r');      
set(h, 'linewidth', 3);
h=plot([ 0 -u(1)*sd(2)], [0 -u(2)*sd(2)], 'r');  
set(h, 'linewidth', 3);
hold off

%% Plot an ellipse that has the first and second principle 
%%% components as its axes
a = sd(1);
b = sd(2);
hold on
t = pi*[0:40]/20;

%%first make ellipse then rotate
ellip = [a* sin(t); b* cos(t)];
h=plot(v'*ellip, -u'*ellip, 'k')
set(h, 'linewidth', 3);

hold off

%% Plot a scatter plot of the PCA unmixing in subplot(2,2,3); the 
%%% unmixed signals are newsig(1,:) and newsig(2,:)

%% (b) Linear mixing of speech sounds
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Read speech sounds
[y1,fs] = audioread('spd.wav');
[y2,fs] = audioread('spc.wav');

%% Take numsamps samples of each sound
numsamps = 40000;
y1=y1(1:numsamps);
y2=y2(1:numsamps);
figure(3); clf;
subplot(2,2,1)
scatter(y1,y2, 'r.')
set(gca, 'DataAspectRatio', [1 1 1])
title('Original Sources')
xlabel('y1')
ylabel('y2')

%% Listen to the sounds
% We have put an if 0 so that you can control if
% to hear the sound. You can copy and paste the lines
% into the Matlab window to hear the sounds.
if 0
soundsc(y1,fs)
soundsc(y2,fs)
end

%% Linearly mix the sounds
mix1 = .6; 
mix2 = .4;
y3 = mix1*y1 + (1-mix1)*y2;
y4 = mix2*y1 + (1-mix2)*y2;
subplot(2,2,2)
scatter(y3,y4, 'b.' )
set(gca, 'DataAspectRatio', [1 1 1])
title('Observed mixtures')
xlabel('mix1')
ylabel('mix2')

%% Listen to the mixed sounds
if 0
soundsc(y3,fs)
soundsc(y4,fs)
end

%% Try PCA. Does it work in separating the sounds? Why?
sig = [y3, y4]';
[pcasig, mat] = mypca(sig);
subplot(2,2,3)
scatter(pcasig(1,:),pcasig(2,:),'b.')
set(gca, 'DataAspectRatio', [1 1 1])
title('Decorrelated components')
xlabel('pca1')
ylabel('pca2')
axis('square');

%% Listen to the pca sounds
if 0
soundsc(pcasig(1,:),fs)
end

%% Try ICA. Does it work in separating the sounds? Why?
[icasig, mat] = ica4(sig);
subplot(2,2,4)
scatter(icasig(1,:),icasig(2,:),'b.')
set(gca, 'DataAspectRatio', [1 1 1])
title('De-mixed components')
xlabel('ica1')
ylabel('ica2')
axis('square');

%% Listen to the ica sounds
if 0
soundsc(icasig(1,:),fs)
soundsc(icasig(2,:),fs)
end

%% *TODO*: Look at the statistics of the sounds using hist
%%% in a new figure

%% *TODO*: Compare statistics to a Gaussian
%%% Use randn to generate a Gaussian named thegauss 
%%% the same size of y1. Plot in the third position
%%% of the figure the histogram, and find the kurtosis
%%% using Matlab's kurtosis function.
%%% How do the speech signals compare to a Gaussian?

subplot(2,2,3);
thegauss = randn(size(y1));
[H,X]=hist(thegauss,101);
plot(X, H);
kurtosis(thegauss)
title('Gaussian distribution');

%% *TODO*: You can also compute the kurtosis of the
%%% pca and ica signals. What do you make of it?
kurtosis(pcasig(1,:))
kurtosis(pcasig(2,:))
kurtosis(pcasig(1,:))
kurtosis(pcasig(2,:))
