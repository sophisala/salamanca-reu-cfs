
%%% This is a tutorial and exercises for linear visual filters.
%%% It includes a simple example of fixed filters using Gabors
%%% (part 1) and learning filters from an image ensemble
%%% (part 2) using linear transforms such as PCA and ICA.

%%% Type 'help <function_name>' in Matlab window for any
%%% function you would like more information on.
%%% Type 'which <function_name>' in Matlab window for the
%%% location of a file.

%%% Odelia Schwartz 2017 for REU; previously used in Berkeley Summer Course 2016 

%%
path(path,'extraFiles')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% (1) Fixed visual filters. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% (1) Visual filters and images
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% (1a) Gabor filters and images

%% Set parameters of sinusoid
sz = 20;
ctr = [round(sz/2+1), round(sz/2+1)];
period = 5;
direction = pi;
phase = 2*pi;
theSine = mkSine(sz, period, direction, 1, phase);
%%% Plot the sinusoid
subplot(2,2,1); showIm(theSine)

%% Make a 2 dimensional Gaussian and plot it
thesig = 2;
theGauss = mkGaussian(sz, thesig, ctr,1);
subplot(2,2,2); showIm(theGauss)

%% Make a Gabor filter, by multiplying a sinusoid with a Gaussian.
theFilt = theSine .* theGauss;
subplot(2,2,3); showIm(theFilt)

%%% 2. Load and filter an image

%% Load an image
im = pgmRead('feynman.pgm');
figure(2); subplot(2,2,1); showIm(im);

%% (1b) Linear response of filter
response = rconv2(im, theFilt); 
figure(2); subplot(2,2,2); showIm(response)

%%% *To do*:
%%% 1. Try making different Gabor filters by varying parameters above
%%% (e.g., direction, period, phase of the grating; and thesig of the Gaussian)
%%% Try reading in different images

imnew = conv2(im,theFilt,'same'); showIm(imnew);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% (2) Optimized filters from images

%%% To optimize from scenes, we will work with a fixed filter
%%% size of 12 by 12. Rather than looking at a full image, we
%%% will consider many samples of 12 by 12 patches from the image.

%%% We will start out by taking many samples of random
%%% patches from an image, and then do a linear transformation
%%% (e.g., PCA, ICA) on the patches.

%% Read in an image -- try different examples
multFact = 256;
im=vanRead('imk00649.iml');
im = multFact*(im./max(max(im)));
im = im(1:512,1:512);
size(im)
close all; figure(1);
showIm(im)

%% *To do": Write a Matlab function
%%% sig = get_patches(im, patch_dim, num_patches)
%%% that takes num_patches random patches from an
%%% input image and saves each patch as a column
%%% of the output matrix sig.
patch_dim = 12;
num_patches = 10000;
sig = get_patches(im, patch_dim, num_patches);
size(sig)

%%% *To do*: Look at example random patches in sig by reshaping
%%%% the columns of the matrix to 12 by 12
showIm(reshape(sig(:,round(rand*num_patches)),patch_dim,patch_dim));
 
%% PCA:
%%% *To do *: Consider linear transformations on the image patch ensemble
%%% of the form: newsig = mat * sig        (where * is multiplication)
%%% First compute a PCA transform of the patches sig.
%%% You can use the function pca, in which you input sig and
%%% obtain as the output newsig, mat (and also the eigenvectors
%%% and eigenvalues). Even better, you can write the pca yourself.
%%% First, do an eigenvector decomposition of sig*sig'./numsigs,
%%% obtaining eigenvalues D and eigenvectors V.
%%% Note that: sig sig' = V D V' with V orthogonal
%%% V' sig sig' V = D; newsig newsig' = D, where newsig = V' sig
%%% Next, sort the eigenvalues and eigenvectors from largest to smallest.
%%% Next, whiten by multiplying the non-zero eigenvalues D by sqrt(1./D). 
%%% Compute the mat matrix as the new D values times V'.
%%% Then compute newsig as mat times sig.

[newsig, evecs, evals, mat]=mypca(sig);


%% *To do*: Confirm that the transform produced newsig that are
%%% uncorrelated.
showIm(newsig*newsig')


%% *To do*: Look at the sizes of sig, newsig, and mat.
%%% Plot the eigenvalues.
%%% Look at the principle components (eigenvectors):
%%% The rows of the matrix mat are called projection functions.
%%% They project from the input columns (patches of image)
%%% onto the principle components.
%%% We can view these by reshaping each row (mat(i,:)) to 12 by 12
%%% What do the eigenvectors look like for high eigenvalues? For low ones?
plot(evals, 'o');
showIm(reshape(mat(round(rand*patch_dim^2),:),patch_dim,patch_dim))
showIm(reshape(mat(1,:),patch_dim,patch_dim))         
showIm(reshape(mat(5,:),patch_dim,patch_dim))         
showIm(reshape(mat(10,:),patch_dim,patch_dim))         

%% *To do*: We are also interested in the transform:
%%% sig = mat_inverse * newsig
%%% This is a transform from the output of pca back to the
%%% original image patches. The matrix mat_inverse is the
%%% inverse of mat. The columns of the matrix mat_inverse
%%% are known as basis functions. The input is a linear
%%% combination of the columns of mat_inverse.
%%% To view the basis functions, we need to view columns of mat_inverse
%%% using matlab's inv(mat). Look at different columns of mat_inverse.
mat_inverse = inv(mat); figure(1);
showIm(reshape(mat_inverse(:,round(rand*patch_dim^2)),patch_dim,patch_dim))
showIm(reshape(mat_inverse(:,1),patch_dim,patch_dim))             
showIm(reshape(mat_inverse(:,10),patch_dim,patch_dim))             

%% Since pca is an orthonormal transform mat*mat_inverse is a diagonal
%%% matrix. Note that if we use pca without whitening then the basis
%%% functions are exactly given by the columns of the transpose
%%% of mat since the inverse is equal to the transpose.
showIm(mat*mat_inverse)

%% We will now look at ICA.
%%% There are several packages available on the web for ICA.

%%% There are various versions of ICA available:
%%% Bell and Sejnowski ICA:
%%% http://cnl.salk.edu/~tony/ica.html
%%% Hoyer and Hyvarinen fast ICA applied to images (imageica):
%%% http://www.cs.helsinki.fi/u/phoyer/software.html
%%% And sparse coding:
%%% Olshausen and Field:
%%% http://redwood.berkeley.edu/bruno/sparsenet/
%%% and fastICA:
%%% http://www.cs.helsinki.fi/u/phoyer/software.html

%% We will use the fastICA code of Hoyer and Hyvarinen
%%% applied to images
%%% http://www.cs.helsinki.fi/u/phoyer/software.html

path(path,'imageica')
path(path,'imageica/code')
path(path,'imageica/results')

clear X;
global X;
X = sig;

%% Pre Whiten
covarianceMatrix = X*X'/size(X,2);
[E, D] = eig(covarianceMatrix);
[dummy,order] = sort(diag(-D));
%order=order:-1:1;
% to make it same as above code
E = E(:,order);
d = diag(D);
d = real(d.^(-0.5));
D = diag(d(order));
X = D*E'*X;
whiteningMatrix = D*E';
dewhiteningMatrix = E*D^(-1);

p.seed = 1;
p.write = 20;
p.model = 'ica';
p.algorithm = 'fixed-point';
p.components = min(size(X));
numIters = 500;            % run for 1000 trials
estimateModif( whiteningMatrix, dewhiteningMatrix, 'tryica.mat', p, numIters );
% Original function is estimate.m which runs infinitely; 
% estimateModif.m runs for numIters times

%% Load saved results
load('tryica.mat');

% *To do*: The columns of A contain the basis functions; view them...
thecol=round(rand*144);
showIm(reshape(A(:,thecol),patch_dim,patch_dim))

