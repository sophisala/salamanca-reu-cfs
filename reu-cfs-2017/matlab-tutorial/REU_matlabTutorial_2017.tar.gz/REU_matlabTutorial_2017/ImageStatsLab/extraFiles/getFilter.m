
function theFilt = getFilter(ori);
%% Creates a steerable filter of given orientation in degrees

%% Choose a filter set (options are 'sp0Filters', 'sp1Filters',
%% 'sp3Filters', 'sp5Filters'):
filts = 'sp3Filters';
[lo0filt,hi0filt,lofilt,bfilts,steermtx,harmonics] = eval(filts);
fsz = round(sqrt(size(bfilts,1))); fsz =  [fsz fsz];
nfilts = size(bfilts,2);
nrows = floor(sqrt(nfilts));

%% "steering" to a new orientation (new_ori in degrees):

theFilt = conv2(reshape(steer(bfilts, ori*pi/180 ), fsz), lo0filt);

